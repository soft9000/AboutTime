#!/bin/bash
cd ./dist
java -jar ./AboutTime.jar
# The above is a simple stopgap. --We will soon deploy our OWN native-code-loader in C/C++ !)
